package com.mytech.backend.portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendOgApplicationTests {

	@Test
	void contextLoads() {
	}

}
